import { useCallback, useEffect, useMemo, useState } from 'react'
import QRCode from 'qrcode'
import { Search, QrCode, Download, Plus, Sparkles, RotateCcw, ScanLine, ClipboardList, BellRing, MapPin, ArrowRight } from 'lucide-react'
import { CATEGORIES, LOCATIONS, STATUSES, STORE, load, save, sampleItems, findMatches, catIcon } from './data.js'
import { ItemCard, ReportModal, ClaimModal, fmtDate } from './components.jsx'

const defaultBase = () => window.location.origin + window.location.pathname
const qrUrl = (base, loc) => `${base}${base.includes('?') ? '&' : '?'}loc=${encodeURIComponent(loc)}`
const matchLoc = (v) => LOCATIONS.find((l) => l.toLowerCase() === String(v || '').toLowerCase()) || ''

function useQr(text, width = 240) {
  const [src, setSrc] = useState('')
  useEffect(() => {
    let live = true
    QRCode.toDataURL(text, { width, margin: 1, color: { dark: '#16233F', light: '#FFFFFF' } }).then((u) => live && setSrc(u)).catch(() => {})
    return () => { live = false }
  }, [text, width])
  return src
}

function QrCard({ loc, base, onTest }) {
  const url = qrUrl(base, loc)
  const src = useQr(url, 512)
  const download = () => {
    const a = document.createElement('a')
    a.href = src; a.download = `scan2find-${loc.toLowerCase().replace(/\s+/g, '-')}.png`; a.click()
  }
  return (
    <div className="card flex flex-col items-center gap-3 p-4 text-center">
      {src ? <img src={src} alt={`QR code for ${loc}`} className="h-44 w-44 rounded-lg" /> : <div className="h-44 w-44 animate-pulse rounded-lg bg-ink/5" />}
      <h3 className="text-lg font-bold">{loc}</h3>
      <div className="flex gap-2">
        <button className="btn-primary !px-3 !py-2" onClick={download} disabled={!src}><Download size={16} />Download</button>
        <button className="btn-ghost !px-3 !py-2" onClick={() => onTest(loc)}><ScanLine size={16} />Test scan</button>
      </div>
    </div>
  )
}

export default function App() {
  const [items, setItems] = useState(() => load(STORE.items, null) || sampleItems())
  const [claims, setClaims] = useState(() => load(STORE.claims, []))
  const [base, setBase] = useState(() => load(STORE.base, '') || defaultBase())
  const [view, setView] = useState('home')
  const [scanned, setScanned] = useState(() => matchLoc(new URLSearchParams(window.location.search).get('loc')))
  const [form, setForm] = useState(null) // { mode, item }
  const [claimItem, setClaimItem] = useState(null)
  const [toast, setToast] = useState('')
  const [flt, setFlt] = useState({ q: '', cat: '', loc: '', type: '' })

  useEffect(() => { if (!save(STORE.items, items)) setToast('Storage is full. Remove photos or old reports.') }, [items])
  useEffect(() => { save(STORE.claims, claims) }, [claims])
  useEffect(() => { save(STORE.base, base) }, [base])
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 3200); return () => clearTimeout(t) }, [toast])
  useEffect(() => { window.scrollTo({ top: 0 }) }, [view])

  const go = useCallback((v, patch) => { if (patch) setFlt((f) => ({ ...f, ...patch })); setView(v) }, [])
  const matches = useMemo(() => findMatches(items), [items])
  const sorted = useMemo(() => [...items].sort((a, b) => b.createdAt - a.createdAt), [items])
  const filtered = useMemo(() => sorted.filter((i) => {
    const q = flt.q.trim().toLowerCase()
    return (!q || (i.name + ' ' + i.description + ' ' + i.location).toLowerCase().includes(q)) &&
      (!flt.cat || i.category === flt.cat) && (!flt.loc || i.location === flt.loc) && (!flt.type || i.type === flt.type)
  }), [sorted, flt])

  const saveItem = (data) => {
    if (form.item) {
      setItems(items.map((i) => (i.id === form.item.id ? { ...i, ...data } : i)))
      setToast('Report updated.')
    } else {
      setItems([{ ...data, id: 'u-' + Date.now(), status: 'Open', mine: true, createdAt: Date.now() }, ...items])
      setToast(data.type === 'lost' ? 'Lost item reported.' : 'Found item reported.')
      setFlt({ q: '', cat: '', loc: '', type: '' }); setView('items')
    }
    setForm(null)
  }
  const del = (item) => { if (window.confirm(`Delete "${item.name}"?`)) { setItems(items.filter((i) => i.id !== item.id)); setToast('Report deleted.') } }
  const setStatus = (id, status) => { setItems(items.map((i) => (i.id === id ? { ...i, status } : i))); setToast(`Status set to ${status}.`) }
  const reset = () => {
    if (!window.confirm('Reset all data back to the demo items? Your reports and claim requests will be removed.')) return
    setItems(sampleItems()); setClaims([]); setToast('Demo data restored.')
  }
  const cardProps = (i) => ({ item: i, matches: matches[i.id] || [], onEdit: (it) => setForm({ mode: it.type, item: it }), onDelete: del, onClaim: setClaimItem })

  const stats = [
    { label: 'Lost items', value: items.filter((i) => i.type === 'lost').length, tone: 'text-lost' },
    { label: 'Found items', value: items.filter((i) => i.type === 'found').length, tone: 'text-found' },
    { label: 'Possible matches', value: Object.keys(matches).filter((id) => items.find((i) => i.id === id)?.type === 'lost').reduce((n, id) => n + matches[id].length, 0), tone: 'text-ink' },
    { label: 'Returned', value: items.filter((i) => i.status === 'Returned').length, tone: 'text-emerald-700' },
  ]
  const nav = [['home', 'Home'], ['items', 'Lost & Found'], ['qr', 'QR codes'], ['dashboard', 'Dashboard']]
  const heroQr = useQr(scanned ? qrUrl(base, scanned) : qrUrl(base, 'Library'), 360)

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-ink text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-1 px-4 py-2.5">
          <button onClick={() => go('home')} className="flex items-center gap-2 text-xl font-extrabold tracking-tight"><span className="grid h-8 w-8 place-items-center rounded-lg bg-scarf text-ink"><ScanLine size={18} /></span>Scan2Find</button>
          <nav className="flex gap-1 overflow-x-auto text-sm font-medium" aria-label="Main">
            {nav.map(([k, l]) => <button key={k} onClick={() => go(k)} aria-current={view === k ? 'page' : undefined} className={`whitespace-nowrap rounded-lg px-3 py-1.5 transition ${view === k ? 'bg-white text-ink' : 'text-white/80 hover:bg-white/10'}`}>{l}</button>)}
          </nav>
        </div>
      </header>

      {scanned && (
        <div className="bg-found text-white">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-sm">
            <p className="flex items-center gap-2 font-medium"><MapPin size={16} />You scanned the <b>{scanned}</b> QR code. Location will be filled in for you.</p>
            <div className="flex gap-2">
              <button className="rounded-lg bg-white px-3 py-1 font-semibold text-lost" onClick={() => setForm({ mode: 'lost' })}>I lost something</button>
              <button className="rounded-lg bg-white px-3 py-1 font-semibold text-found" onClick={() => setForm({ mode: 'found' })}>I found something</button>
              <button className="px-2 underline" onClick={() => setScanned('')}>Dismiss</button>
            </div>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 py-8 sm:py-10">
        {view === 'home' && (
          <div className="space-y-14">
            <section className="grid items-center gap-8 md:grid-cols-[1.3fr_1fr]">
              <div>
                <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">Lost it on campus? Scan the spot, find it faster.</h1>
                <p className="mt-4 max-w-prose text-lg text-ink/70">Every library desk, canteen and lab has a Scan2Find QR code. Scan it, report what you lost or found, and we flag items that look like a match.</p>
                <form className="mt-6 flex max-w-xl gap-2" onSubmit={(e) => { e.preventDefault(); go('items') }}>
                  <div className="relative flex-1"><Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink/40" /><input className="field !py-3 pl-10" aria-label="Search items" placeholder="Search e.g. earbuds, ID card, keys" value={flt.q} onChange={(e) => setFlt({ ...flt, q: e.target.value })} /></div>
                  <button className="btn-primary">Search</button>
                </form>
                <div className="mt-4 flex flex-wrap gap-3">
                  <button className="btn-lost" onClick={() => setForm({ mode: 'lost' })}><Plus size={18} />I Lost Something</button>
                  <button className="btn-found" onClick={() => setForm({ mode: 'found' })}><Plus size={18} />I Found Something</button>
                </div>
              </div>
              <div className="mx-auto w-full max-w-[300px]">
                <div className="relative overflow-hidden rounded-3xl border-4 border-ink bg-white p-4 shadow-xl shadow-ink/20">
                  {heroQr && <img src={heroQr} alt={`Sample QR code for ${scanned || 'Library'}`} className="w-full" />}
                  <div className="pointer-events-none absolute inset-x-3 h-1 animate-scan rounded-full bg-scarf shadow-[0_0_18px_4px_#F2B632]" />
                </div>
                <p className="mt-3 text-center text-sm font-medium text-ink/60">{scanned || 'Library'} QR code</p>
              </div>
            </section>

            <section>
              <h2 className="mb-4 text-2xl font-bold">Browse by category</h2>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((c) => <button key={c.name} onClick={() => go('items', { cat: c.name, q: '' })} className="rounded-full border border-ink/15 bg-white px-4 py-2 text-sm font-medium transition hover:border-ink hover:bg-ink hover:text-white">{c.icon} {c.name}</button>)}
              </div>
            </section>

            <section>
              <div className="mb-4 flex items-end justify-between"><h2 className="text-2xl font-bold">Recently reported</h2><button className="flex items-center gap-1 text-sm font-semibold underline" onClick={() => go('items', { q: '', cat: '', loc: '', type: '' })}>See all <ArrowRight size={16} /></button></div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{sorted.slice(0, 4).map((i) => <ItemCard key={i.id} {...cardProps(i)} />)}</div>
            </section>

            <section>
              <h2 className="mb-4 text-2xl font-bold">How it works</h2>
              <ol className="grid gap-4 md:grid-cols-3">
                {[[ScanLine, 'Scan the QR code', 'Find the code at the spot where you lost or found something. The location is filled in for you.'], [ClipboardList, 'Report the item', 'Add a name, photo and description. It shows up on the board right away.'], [BellRing, 'Get matched', 'We compare names, categories, descriptions and locations and mark likely pairs as Possible Match.']].map(([Icon, t, d], n) => (
                  <li key={t} className="card p-5"><div className="mb-3 flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-scarf font-extrabold">{n + 1}</span><Icon size={22} /></div><h3 className="text-lg font-bold">{t}</h3><p className="mt-1 text-sm text-ink/70">{d}</p></li>
                ))}
              </ol>
            </section>
            <p className="rounded-2xl bg-ink/5 p-4 text-sm text-ink/70">Good to know: reports are saved in your browser's localStorage. They stay on this device and browser only and will not appear for other people automatically.</p>
          </div>
        )}

        {view === 'items' && (
          <div>
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><h1 className="text-3xl font-extrabold">Lost &amp; Found board</h1>
              <div className="flex gap-2"><button className="btn-lost" onClick={() => setForm({ mode: 'lost' })}><Plus size={16} />I Lost Something</button><button className="btn-found" onClick={() => setForm({ mode: 'found' })}><Plus size={16} />I Found Something</button></div></div>
            <div className="card mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" /><input className="field pl-9" aria-label="Search by item name" placeholder="Search item name" value={flt.q} onChange={(e) => setFlt({ ...flt, q: e.target.value })} /></div>
              <select className="field" aria-label="Category" value={flt.cat} onChange={(e) => setFlt({ ...flt, cat: e.target.value })}><option value="">All categories</option>{CATEGORIES.map((c) => <option key={c.name}>{c.name}</option>)}</select>
              <select className="field" aria-label="Location" value={flt.loc} onChange={(e) => setFlt({ ...flt, loc: e.target.value })}><option value="">All locations</option>{LOCATIONS.map((l) => <option key={l}>{l}</option>)}</select>
              <select className="field" aria-label="Type" value={flt.type} onChange={(e) => setFlt({ ...flt, type: e.target.value })}><option value="">Lost and found</option><option value="lost">Lost only</option><option value="found">Found only</option></select>
            </div>
            {filtered.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map((i) => <ItemCard key={i.id} {...cardProps(i)} />)}</div> : (
              <div className="card p-10 text-center"><p className="text-lg font-semibold">No items match these filters.</p><button className="btn-ghost mt-4" onClick={() => setFlt({ q: '', cat: '', loc: '', type: '' })}>Clear filters</button></div>
            )}
          </div>
        )}

        {view === 'qr' && (
          <div>
            <h1 className="text-3xl font-extrabold">QR codes for campus locations</h1>
            <p className="mt-2 max-w-prose text-ink/70">Download a code, print it and stick it at the location. Scanning it opens Scan2Find with that location already selected.</p>
            <div className="card my-5 p-4">
              <label className="label" htmlFor="base">Website address inside the QR codes</label>
              <div className="flex flex-wrap gap-2"><input id="base" className="field flex-1" value={base} onChange={(e) => setBase(e.target.value.trim())} /><button className="btn-ghost" onClick={() => setBase(defaultBase())}>Use current address</button></div>
              <p className="mt-2 text-xs text-ink/60">Phones can't open "localhost". After you deploy the site (Netlify, Vercel, GitHub Pages), paste its public address here, then download the codes.</p>
            </div>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">{LOCATIONS.map((l) => <QrCard key={l} loc={l} base={base} onTest={(loc) => { setScanned(loc); setView('home'); setToast(`Scanned ${loc}.`) }} />)}</div>
          </div>
        )}

        {view === 'dashboard' && (
          <div className="space-y-8">
            <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-3xl font-extrabold">Dashboard</h1><button className="btn-ghost" onClick={reset}><RotateCcw size={16} />Reset demo data</button></div>
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{stats.map((s) => <div key={s.label} className="card p-5"><p className={`text-4xl font-extrabold ${s.tone}`}>{s.value}</p><p className="mt-1 text-sm text-ink/70">{s.label}</p></div>)}</div>

            <section>
              <h2 className="mb-3 flex items-center gap-2 text-xl font-bold"><Sparkles size={20} />Possible matches</h2>
              {(() => {
                const pairs = items.filter((i) => i.type === 'lost').flatMap((l) => (matches[l.id] || []).map((m) => ({ l, f: m.item, score: m.score })))
                return pairs.length ? <div className="grid gap-3 md:grid-cols-2">{pairs.map(({ l, f, score }) => (
                  <div key={l.id + f.id} className="card flex items-center justify-between gap-3 p-4 text-sm"><div><p><span className="font-bold text-lost">Lost:</span> {l.name} <span className="text-ink/50">({l.location})</span></p><p><span className="font-bold text-found">Found:</span> {f.name} <span className="text-ink/50">({f.location})</span></p></div><span className="rounded-full bg-scarf/40 px-3 py-1 font-bold">{score}%</span></div>
                ))}</div> : <p className="card p-4 text-sm text-ink/70">No possible matches right now.</p>
              })()}
            </section>

            <section>
              <h2 className="mb-3 text-xl font-bold">Update status</h2>
              <div className="card overflow-x-auto">
                <table className="w-full min-w-[560px] text-left text-sm">
                  <thead className="border-b border-ink/10 text-ink/60"><tr><th className="p-3">Item</th><th className="p-3">Type</th><th className="p-3">Location</th><th className="p-3">Date</th><th className="p-3">Status</th></tr></thead>
                  <tbody>{sorted.map((i) => (
                    <tr key={i.id} className="border-b border-ink/5 last:border-0">
                      <td className="p-3 font-medium">{catIcon(i.category)} {i.name}</td>
                      <td className={`p-3 font-semibold ${i.type === 'lost' ? 'text-lost' : 'text-found'}`}>{i.type === 'lost' ? 'Lost' : 'Found'}</td>
                      <td className="p-3">{i.location}</td><td className="p-3">{fmtDate(i.date)}</td>
                      <td className="p-3"><select className="field !py-1.5" aria-label={`Status of ${i.name}`} value={i.status} onChange={(e) => setStatus(i.id, e.target.value)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></td>
                    </tr>))}</tbody>
                </table>
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-xl font-bold">Claim requests</h2>
              {claims.length ? <ul className="grid gap-3 md:grid-cols-2">{claims.map((c) => <li key={c.id} className="card p-4 text-sm"><p className="font-bold">{c.itemName}</p><p className="text-ink/60">{c.name} · {c.contact} · {new Date(c.at).toLocaleString()}</p><p className="mt-2">{c.message}</p></li>)}</ul> : <p className="card p-4 text-sm text-ink/70">No claim requests yet. Use "This is mine" or "I found this" on any item card.</p>}
            </section>
          </div>
        )}
      </main>

      <footer className="border-t border-ink/10 py-6 text-center text-xs text-ink/60">Scan2Find · Frontend-only demo. Data lives in this browser's localStorage.</footer>

      {form && <ReportModal mode={form.mode} item={form.item} defaultLocation={scanned} onSave={saveItem} onClose={() => setForm(null)} />}
      {claimItem && <ClaimModal item={claimItem} onClose={() => setClaimItem(null)} onSubmit={(c) => { setClaims([{ ...c, id: 'c-' + Date.now(), at: Date.now() }, ...claims]); setClaimItem(null); setToast('Claim request saved (demo).') }} />}
      {toast && <div role="status" className="fixed bottom-4 left-1/2 z-[60] -translate-x-1/2 animate-pop rounded-xl bg-ink px-5 py-3 text-sm font-medium text-white shadow-xl">{toast}</div>}
    </div>
  )
}
