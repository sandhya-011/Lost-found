export const LOCATIONS = ['Library', 'Canteen', 'Classroom 101', 'Classroom 204', 'Computer Lab', 'Physics Lab', 'Chemistry Lab', 'Sports Ground', 'Main Gate', 'Auditorium']
export const CATEGORIES = [
  { name: 'Electronics', icon: '📱' }, { name: 'Books & Notes', icon: '📚' }, { name: 'ID & Cards', icon: '🪪' },
  { name: 'Bags', icon: '🎒' }, { name: 'Keys', icon: '🔑' }, { name: 'Clothing', icon: '🧥' },
  { name: 'Accessories', icon: '⌚' }, { name: 'Other', icon: '📦' },
]
export const STATUSES = ['Open', 'Matched', 'Claimed', 'Returned']
export const catIcon = (n) => CATEGORIES.find((c) => c.name === n)?.icon || '📦'

const KEYS = { items: 'scan2find.items.v1', claims: 'scan2find.claims.v1', base: 'scan2find.baseurl.v1' }
export const STORE = KEYS
export const load = (key, fallback) => {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback } catch { return fallback }
}
export const save = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); return true } catch { return false }
}

const DAY = 86400000
const iso = (n) => new Date(Date.now() - n * DAY).toISOString().slice(0, 10)
const mk = (i, type, name, category, description, location, ago, extra = {}) => ({
  id: 'demo-' + i, type, name, category, description, location, date: iso(ago), photo: '', status: 'Open',
  reporter: extra.reporter || 'Demo Student', contact: 'demo@college.edu', mine: false, createdAt: Date.now() - ago * DAY - i, ...extra,
})
export const sampleItems = () => [
  mk(1, 'lost', 'Black Wireless Earbuds', 'Electronics', 'Black earbuds in a small white charging case with a scratch on the lid.', 'Library', 1),
  mk(2, 'found', 'Black earbuds case', 'Electronics', 'Found a white charging case with black wireless earbuds on a reading table.', 'Library', 0, { reporter: 'Library Desk' }),
  mk(3, 'lost', 'Blue Water Bottle', 'Other', 'Steel blue bottle with a sticker of a mountain. Has a small dent.', 'Canteen', 2),
  mk(4, 'found', 'Student ID Card', 'ID & Cards', 'ID card of a second year student, found near the notice board.', 'Main Gate', 1, { reporter: 'Security Office' }),
  mk(5, 'lost', 'Physics Notebook', 'Books & Notes', 'Green spiral notebook with optics notes, name written on first page.', 'Physics Lab', 3),
  mk(6, 'found', 'Bunch of keys', 'Keys', 'Three keys on a red ring with a small football keychain.', 'Sports Ground', 2, { reporter: 'Coach Rao' }),
  mk(7, 'found', 'Grey Hoodie', 'Clothing', 'Grey zip-up hoodie, size M, left on a chair after the lecture.', 'Classroom 204', 4, { status: 'Claimed' }),
  mk(8, 'lost', 'Scientific Calculator', 'Electronics', 'Casio scientific calculator with initials R.K. on the back.', 'Computer Lab', 5, { status: 'Returned' }),
]

export const fileToDataUrl = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader()
  reader.onerror = reject
  reader.onload = () => {
    const img = new Image()
    img.onerror = reject
    img.onload = () => {
      const s = Math.min(1, 480 / Math.max(img.width, img.height))
      const c = document.createElement('canvas')
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s)
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      resolve(c.toDataURL('image/jpeg', 0.7))
    }
    img.src = reader.result
  }
  reader.readAsDataURL(file)
})

// ---- Smart matching (plain JavaScript, no AI) ----
const STOP = new Set(['a', 'an', 'the', 'of', 'in', 'on', 'at', 'with', 'and', 'or', 'to', 'is', 'was', 'near', 'has', 'have', 'found', 'lost', 'left', 'small', 'my', 'it', 'for', 'by'])
const tokens = (s) => new Set(String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w)).map((w) => w.replace(/s$/, '')))
const overlap = (a, b) => {
  if (!a.size || !b.size) return 0
  let n = 0; a.forEach((w) => b.has(w) && n++)
  return n / Math.min(a.size, b.size)
}
export const matchScore = (a, b) => {
  const nameO = overlap(tokens(a.name), tokens(b.name))
  const descO = overlap(tokens(a.name + ' ' + a.description), tokens(b.name + ' ' + b.description))
  const score = nameO * 45 + descO * 15 + (a.category === b.category ? 20 : 0) + (a.location === b.location ? 20 : 0)
  return Math.round(score)
}
// Returns { [itemId]: [{ item, score }] } for every open lost/found pair scoring >= 50.
export const findMatches = (items) => {
  const active = items.filter((i) => i.status !== 'Returned')
  const out = {}
  active.filter((i) => i.type === 'lost').forEach((l) => {
    active.filter((i) => i.type === 'found').forEach((f) => {
      const score = matchScore(l, f)
      if (score >= 50) {
        ;(out[l.id] ||= []).push({ item: f, score })
        ;(out[f.id] ||= []).push({ item: l, score })
      }
    })
  })
  Object.values(out).forEach((a) => a.sort((x, y) => y.score - x.score))
  return out
}
