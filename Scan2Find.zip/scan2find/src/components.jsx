import { useEffect, useState } from 'react'
import { MapPin, CalendarDays, Pencil, Trash2, Sparkles, X, HandHelping, Camera } from 'lucide-react'
import { CATEGORIES, LOCATIONS, catIcon, fileToDataUrl } from './data.js'

const statusStyle = { Open: 'bg-ink/10 text-ink', Matched: 'bg-scarf/30 text-ink', Claimed: 'bg-blue-100 text-blue-900', Returned: 'bg-emerald-100 text-emerald-900' }
export const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })

export function ItemCard({ item, matches = [], onEdit, onDelete, onClaim }) {
  const lost = item.type === 'lost'
  return (
    <article className="card flex animate-pop flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-ink/10">
      <div className={`relative flex h-40 items-center justify-center ${lost ? 'bg-lost/10' : 'bg-found/10'}`}>
        {item.photo ? <img src={item.photo} alt={item.name} className="h-full w-full object-cover" /> : <span className="text-6xl" aria-hidden>{catIcon(item.category)}</span>}
        <span className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-bold text-white ${lost ? 'bg-lost' : 'bg-found'}`}>{lost ? 'Lost' : 'Found'}</span>
        <span className={`absolute right-3 top-3 rounded-full px-3 py-1 text-xs font-semibold ${statusStyle[item.status]}`}>{item.status}</span>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="text-lg font-bold leading-tight">{item.name}</h3>
        <p className="line-clamp-2 text-sm text-ink/70">{item.description || 'No description added.'}</p>
        <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink/60">
          <span className="flex items-center gap-1"><MapPin size={14} />{item.location}</span>
          <span className="flex items-center gap-1"><CalendarDays size={14} />{fmtDate(item.date)}</span>
          <span>{catIcon(item.category)} {item.category}</span>
        </div>
        {matches.length > 0 && (
          <div className="mt-1 rounded-xl bg-scarf/25 p-2.5 text-xs">
            <p className="flex items-center gap-1 font-bold"><Sparkles size={14} />Possible Match</p>
            <p className="mt-0.5 text-ink/80">{matches[0].item.name} ({matches[0].score}% similar){matches.length > 1 && ` +${matches.length - 1} more`}</p>
          </div>
        )}
        <div className="mt-auto flex flex-wrap gap-2 pt-3">
          {item.status !== 'Returned' && <button className="btn-ghost !px-3 !py-1.5" onClick={() => onClaim(item)}><HandHelping size={16} />{lost ? 'I found this' : 'This is mine'}</button>}
          {item.mine && <>
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => onEdit(item)} aria-label={`Edit ${item.name}`}><Pencil size={16} />Edit</button>
            <button className="btn-ghost !px-3 !py-1.5 text-lost" onClick={() => onDelete(item)} aria-label={`Delete ${item.name}`}><Trash2 size={16} />Delete</button>
          </>}
        </div>
      </div>
    </article>
  )
}

export function Modal({ title, onClose, children }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/60 p-0 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className="max-h-[92vh] w-full max-w-lg animate-pop overflow-y-auto rounded-t-3xl bg-paper p-5 sm:rounded-3xl sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold">{title}</h2>
          <button onClick={onClose} className="rounded-full p-2 hover:bg-ink/10" aria-label="Close"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function ReportModal({ mode, item, defaultLocation, onSave, onClose }) {
  const editing = !!item
  const type = item?.type || mode
  const [f, setF] = useState({
    name: item?.name || '', category: item?.category || '', description: item?.description || '',
    date: item?.date || new Date().toISOString().slice(0, 10), location: item?.location || defaultLocation || '',
    photo: item?.photo || '', reporter: item?.reporter || '', contact: item?.contact || '',
  })
  const [err, setErr] = useState({})
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const pick = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    try { setF({ ...f, photo: await fileToDataUrl(file) }) } catch { setErr({ photo: 'Could not read that image. Try a JPG or PNG.' }) }
  }
  const submit = (e) => {
    e.preventDefault()
    const er = {}
    if (!f.name.trim()) er.name = 'Enter the item name.'
    if (!f.category) er.category = 'Choose a category.'
    if (!f.location) er.location = 'Choose a location.'
    if (!f.date) er.date = 'Pick the date.'
    setErr(er)
    if (Object.keys(er).length) return
    onSave({ ...f, name: f.name.trim(), type })
  }
  const E = ({ k }) => err[k] ? <p className="mt-1 text-xs text-lost">{err[k]}</p> : null
  return (
    <Modal title={`${editing ? 'Edit' : 'Report'}: ${type === 'lost' ? 'I lost something' : 'I found something'}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3" noValidate>
        {defaultLocation && !editing && <p className="rounded-xl bg-found/10 p-2.5 text-sm text-found">Location filled in from your QR scan: <b>{defaultLocation}</b></p>}
        <div><label className="label" htmlFor="f-name">Item name</label><input id="f-name" className="field" value={f.name} onChange={set('name')} placeholder="e.g. Black backpack" /><E k="name" /></div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="f-cat">Category</label>
            <select id="f-cat" className="field" value={f.category} onChange={set('category')}><option value="">Select…</option>{CATEGORIES.map((c) => <option key={c.name}>{c.name}</option>)}</select><E k="category" /></div>
          <div><label className="label" htmlFor="f-date">Date {type === 'lost' ? 'lost' : 'found'}</label>
            <input id="f-date" type="date" max={new Date().toISOString().slice(0, 10)} className="field" value={f.date} onChange={set('date')} /><E k="date" /></div>
        </div>
        <div><label className="label" htmlFor="f-loc">Location</label>
          <select id="f-loc" className="field" value={f.location} onChange={set('location')}><option value="">Select…</option>{LOCATIONS.map((l) => <option key={l}>{l}</option>)}</select><E k="location" /></div>
        <div><label className="label" htmlFor="f-desc">Description</label>
          <textarea id="f-desc" rows={3} className="field" value={f.description} onChange={set('description')} placeholder="Colour, brand, marks, what was inside…" /></div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="f-rep">Your name</label><input id="f-rep" className="field" value={f.reporter} onChange={set('reporter')} placeholder="Optional" /></div>
          <div><label className="label" htmlFor="f-con">Contact (demo)</label><input id="f-con" className="field" value={f.contact} onChange={set('contact')} placeholder="Email or phone" /></div>
        </div>
        <div>
          <label className="label">Photo (optional)</label>
          <label className="btn-ghost w-full cursor-pointer"><Camera size={16} />{f.photo ? 'Change photo' : 'Add photo'}<input type="file" accept="image/*" className="sr-only" onChange={pick} /></label>
          <E k="photo" />
          {f.photo && <img src={f.photo} alt="Preview" className="mt-2 h-28 w-full rounded-xl object-cover" />}
        </div>
        <button className={type === 'lost' ? 'btn-lost w-full' : 'btn-found w-full'}>{editing ? 'Save changes' : type === 'lost' ? 'Report lost item' : 'Report found item'}</button>
      </form>
    </Modal>
  )
}

export function ClaimModal({ item, onSubmit, onClose }) {
  const [f, setF] = useState({ name: '', contact: '', message: '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const lost = item.type === 'lost'
  return (
    <Modal title={lost ? 'Tell the owner you found it' : 'Claim this item'} onClose={onClose}>
      <p className="mb-3 text-sm text-ink/70">You are contacting <b>{item.reporter || 'the reporter'}</b> about <b>{item.name}</b>. Demo only: nothing is sent, the request is saved in this browser.</p>
      <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit({ ...f, itemId: item.id, itemName: item.name }) }}>
        <div><label className="label" htmlFor="c-name">Your name</label><input id="c-name" required className="field" value={f.name} onChange={set('name')} /></div>
        <div><label className="label" htmlFor="c-con">Your contact</label><input id="c-con" required className="field" value={f.contact} onChange={set('contact')} placeholder="Email or phone" /></div>
        <div><label className="label" htmlFor="c-msg">Message</label><textarea id="c-msg" required rows={3} className="field" value={f.message} onChange={set('message')} placeholder={lost ? 'Where is the item now?' : 'Describe a detail only the owner would know.'} /></div>
        <button className="btn-primary w-full">Send request</button>
      </form>
    </Modal>
  )
}
