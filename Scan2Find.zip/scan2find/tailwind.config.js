/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'] },
      colors: {
        ink: '#16233F', paper: '#F5F6FA', scarf: '#F2B632',
        lost: '#E4572E', found: '#12907F',
      },
      keyframes: {
        scan: { '0%,100%': { top: '6%' }, '50%': { top: '90%' } },
        pop: { from: { opacity: 0, transform: 'translateY(12px) scale(.97)' }, to: { opacity: 1, transform: 'none' } },
      },
      animation: { scan: 'scan 3.2s ease-in-out infinite', pop: 'pop .22s ease-out' },
    },
  },
  plugins: [],
}
