# Scan2Find — Smart Campus Lost & Found

Frontend-only React + Tailwind CSS app. No backend, database, login or external APIs.

## Run
```
npm install
npm run dev        # development
npm run build      # production build in /dist
```

## QR codes
Open **QR codes** in the app. Phones cannot open `localhost`, so deploy the built site (Netlify, Vercel, GitHub Pages),
paste the public address into the "Website address" box, then download and print the codes.
Scanning opens `your-site/?loc=Library` and pre-fills the location. Use "Test scan" to try it without a phone.

## Data storage
Reports are saved in the browser's localStorage. They persist after refresh, but exist **only in the same browser on the same
device** and will not appear for other users. Use Dashboard > "Reset demo data" to restore the sample items.
Only reports created in your browser can be edited or deleted; status can be updated for any item in the Dashboard.

## Smart matching
`src/data.js` > `matchScore`: name word overlap (45) + description overlap (15) + same category (20) + same location (20).
Pairs of lost/found items scoring 50 or more are labelled "Possible Match".
